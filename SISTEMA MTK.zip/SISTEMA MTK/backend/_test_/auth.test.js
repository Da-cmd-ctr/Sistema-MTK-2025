// backend/__tests__/auth.test.js
const request = require("supertest");

// Mock del módulo ../db (exactamente el path que usa app/routers)
jest.mock("../db", () => {
  // Tienda en memoria para simular la tabla usuarios
  const store = {
    usuarios: [
      { Usuario: "admin", Contrasena: "1234", Estado: "activo", Rol: "ADMIN" },
      { Usuario: "juan", Contrasena: "abcd", Estado: "inactivo", Rol: "USER" }
    ]
  };

  return {
    // Simulamos db.query(sql, params, cb)
    query: (sql, params, cb) => {
      if (sql.startsWith("SELECT * FROM usuarios WHERE")) {
        const [u, p] = params;
        const rows = store.usuarios.filter(
          r => r.Usuario === u && r.Contrasena === p && r.Estado === "activo"
        );
        return cb(null, rows, []);
      }
      if (sql.startsWith("SELECT * FROM usuarios")) {
        return cb(null, store.usuarios, []);
      }
      return cb(null, [], []);
    }
  };
});

const app = require("../app");

describe("POST /ingresoSistema", () => {
  test("✅ Credenciales válidas y usuario activo", async () => {
    const res = await request(app)
      .post("/ingresoSistema")
      .send({ usuario: "admin", password: "1234" });

    expect(res.statusCode).toBe(200);
    expect(res.body.ok).toBe(true);
    expect(res.body.usuario.Usuario).toBe("admin");
  });

  test("❌ Usuario inactivo", async () => {
    const res = await request(app)
      .post("/ingresoSistema")
      .send({ usuario: "juan", password: "abcd" });

    expect(res.statusCode).toBe(401);
    expect(res.body.ok).toBe(false);
  });

  test("❌ Password incorrecto", async () => {
    const res = await request(app)
      .post("/ingresoSistema")
      .send({ usuario: "admin", password: "wrong" });

    expect(res.statusCode).toBe(401);
    expect(res.body.ok).toBe(false);
  });

  test("❌ Datos incompletos", async () => {
    const res = await request(app)
      .post("/ingresoSistema")
      .send({ usuario: "admin" });

    expect(res.statusCode).toBe(400);
    expect(res.body.ok).toBe(false);
  });
});

describe("GET /usuarios", () => {
  test("✅ Devuelve listado simulado", async () => {
    const res = await request(app).get("/usuarios");
    expect(res.statusCode).toBe(200);
    expect(res.body.ok).toBe(true);
    expect(Array.isArray(res.body.data)).toBe(true);
    expect(res.body.data.length).toBeGreaterThan(0);
  });
});
