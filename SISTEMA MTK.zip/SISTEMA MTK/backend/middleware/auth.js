const jwt = require('jsonwebtoken');

function verificarToken(req, res, next) {
  const header = req.headers['authorization'];
  if (!header) return res.status(401).json({ ok:false, mensaje:'Token requerido' });

  const [bearer, token] = header.split(' ');
  if (bearer !== 'Bearer' || !token) {
    return res.status(401).json({ ok:false, mensaje:'Formato de Authorization inválido' });
  }
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET); // { id, rol, iat, exp }
    next();
  } catch (err) {
    return res.status(401).json({ ok:false, mensaje:'Token inválido o expirado' });
  }
}

module.exports = { verificarToken };
