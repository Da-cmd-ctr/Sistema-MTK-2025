function authorize(...rolesPermitidos) {
  const allowAll = rolesPermitidos.includes('*');
  return (req, res, next) => {
    const rol = (req.user && req.user.rol) ? String(req.user.rol).toLowerCase() : null;
    if (!rol) return res.status(403).json({ ok:false, mensaje:'No autenticado o sin rol' });
    if (allowAll) return next();

    const permitidos = rolesPermitidos.map(r => String(r).toLowerCase());
    if (!permitidos.includes(rol)) {
      return res.status(403).json({ ok:false, mensaje:'Acceso denegado para tu rol' });
    }
    next();
  };
}

module.exports = { authorize };
