require('dotenv').config();
const bcrypt = require('bcrypt');
const { pool } = require('../db');

(async () => {
  try {
    const [usuarios] = await pool.query('SELECT idUsuarios, Password FROM Usuarios');

    for (const u of usuarios) {
      const pwd = u.Password || '';
      // Si ya es bcrypt ($2a/$2b/$2y), lo saltamos
      if (/^\$2[aby]\$/.test(pwd)) continue;

      const hash = await bcrypt.hash(pwd, 10);
      await pool.query('UPDATE Usuarios SET Password = ? WHERE idUsuarios = ?', [hash, u.idUsuarios]);
      console.log(`Hasheado id=${u.idUsuarios}`);
    }
    console.log('✅ Migración completa');
    process.exit(0);
  } catch (e) {
    console.error('❌ Error migrando:', e);
    process.exit(1);
  }
})();
