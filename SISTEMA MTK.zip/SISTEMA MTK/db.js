﻿const mysql = require("mysql2");
require("dotenv").config();

const db = mysql.createConnection({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASS || "",
  database: process.env.DB_NAME || "bd_mtk2",
});

db.connect((err) => {
  if (err) console.error("❌ Error DB:", err.message);
  else console.log("✅ Conexión DB OK");
});

module.exports = db;
